import pygame
import sys
import os
import random

# Initialize
pygame.init()

# Constants
WIDTH, HEIGHT = 640, 640
ROWS, COLS = 8, 8
SQUARE_SIZE = WIDTH // COLS

WHITE = (255, 255, 255)  # White square
BROWN = (181, 136, 99)   # Brown square
BLUE = (50, 150, 255)    # Highlight color
RED = (255, 0, 0)        # Error message color


# Fonts
FONT = pygame.font.SysFont("Arial", 24)

# Set up window
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("2D Chess Game")

# Load piece images
pieces = {}
for color in ['w', 'b']:
    for name in ['P', 'R', 'N', 'B', 'Q', 'K']:
        img_path = os.path.join("assets", f"{color}{name}.png")
        image = pygame.image.load(img_path)
        pieces[f"{color}{name}"] = pygame.transform.scale(image, (SQUARE_SIZE, SQUARE_SIZE))

# Initial board setup
def init_board():
    board = [["" for _ in range(COLS)] for _ in range(ROWS)]
    board[0] = ["bR", "bN", "bB", "bQ", "bK", "bB", "bN", "bR"]
    board[1] = ["bP"] * 8
    board[6] = ["wP"] * 8
    board[7] = ["wR", "wN", "wB", "wQ", "wK", "wB", "wN", "wR"]
    return board

board = init_board()
selected_square = None
turn = "w"
error_message = ""

# Draw chess board and pieces
def draw_board():
    for row in range(ROWS):
        for col in range(COLS):
            color = WHITE if (row + col) % 2 == 0 else BROWN
            pygame.draw.rect(screen, color, (col * SQUARE_SIZE, row * SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE))

            if selected_square == (row, col):
                pygame.draw.rect(screen, BLUE, (col * SQUARE_SIZE, row * SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE), 4)

            piece = board[row][col]
            if piece != "":
                screen.blit(pieces[piece], (col * SQUARE_SIZE, row * SQUARE_SIZE))

    if error_message:
        text = FONT.render(error_message, True, RED)
        screen.blit(text, (10, HEIGHT - 30))

# Get board coordinates from mouse position
def get_square(pos):
    x, y = pos
    return y // SQUARE_SIZE, x // SQUARE_SIZE

# Proper move validation
def is_valid_piece_move(piece, start, end):
    sr, sc = start
    er, ec = end
    dr, dc = er - sr, ec - sc

    ptype = piece[1]
    if ptype == "P":  # Pawn
        direction = -1 if piece[0] == "w" else 1
        if dc == 0 and board[er][ec] == "":
            if dr == direction:
                return True
            if (sr == 6 and direction == -1 or sr == 1 and direction == 1) and dr == 2 * direction and board[sr + direction][sc] == "":
                return True
        if abs(dc) == 1 and dr == direction and board[er][ec] != "" and board[er][ec][0] != piece[0]:
            return True
    elif ptype == "R":  # Rook
        if sr == er or sc == ec:
            return clear_path(start, end)
    elif ptype == "N":  # Knight
        if (abs(dr), abs(dc)) in [(2, 1), (1, 2)]:
            return True
    elif ptype == "B":  # Bishop
        if abs(dr) == abs(dc):
            return clear_path(start, end)
    elif ptype == "Q":  # Queen
        if sr == er or sc == ec or abs(dr) == abs(dc):
            return clear_path(start, end)
    elif ptype == "K":  # King
        if max(abs(dr), abs(dc)) == 1:
            return True

    return False

# Clear path for sliding pieces
def clear_path(start, end):
    sr, sc = start
    er, ec = end
    dr = (er - sr) // max(1, abs(er - sr)) if er != sr else 0
    dc = (ec - sc) // max(1, abs(ec - sc)) if ec != sc else 0

    r, c = sr + dr, sc + dc
    while (r, c) != (er, ec):
        if board[r][c] != "":
            return False
        r += dr
        c += dc
    return True

# Full move validation
def is_valid_move(start, end):
    sr, sc = start
    er, ec = end
    piece = board[sr][sc]
    target = board[er][ec]

    if piece == "":
        return False, "No piece selected!"
    if piece[0] != turn:
        return False, "Not your turn!"
    if target != "" and target[0] == turn:
        return False, "Can't capture own piece!"
    if not is_valid_piece_move(piece, start, end):
        return False, "Invalid move for piece!"
    return True, ""

# Move piece
def move_piece(start, end):
    sr, sc = start
    er, ec = end
    piece = board[sr][sc]
    board[er][ec] = piece
    board[sr][sc] = ""

    # Check for pawn promotion
    if piece[1] == "P":
        if (piece[0] == "w" and er == 0) or (piece[0] == "b" and er == 7):
            board[er][ec] = piece[0] + "Q"  # promote to Queen

# Find the position of the king
def find_king(color):
    for r in range(8):
        for c in range(8):
            if board[r][c] == color + "K":
                return (r, c)
    return None

# Check if a square is attacked by an opponent's piece
def is_square_attacked(square, by_color):
    r, c = square
    for sr in range(8):
        for sc in range(8):
            piece = board[sr][sc]
            if piece != "" and piece[0] == by_color:
                if is_valid_piece_move(piece, (sr, sc), (r, c)) and clear_path((sr, sc), (r, c)):
                    return True
    return False

# Check the game state (check, checkmate, stalemate)
def check_game_state():
    global error_message
    enemy = "b" if turn == "w" else "w"
    king_pos = find_king(enemy)
    if king_pos and is_square_attacked(king_pos, turn):
        moves = get_all_possible_moves(enemy)
        if not moves:
            error_message = f"Checkmate! {turn.upper()} wins!"
        else:
            error_message = f"{enemy.upper()} King is in Check!"
    else:
        moves = get_all_possible_moves(enemy)
        if not moves:
            error_message = "Stalemate!"

# Get all possible moves for a color
def get_all_possible_moves(color):
    moves = []
    for r in range(ROWS):
        for c in range(COLS):
            piece = board[r][c]
            if piece != "" and piece[0] == color:
                for er in range(8):
                    for ec in range(8):
                        valid, _ = is_valid_move((r, c), (er, ec))
                        if valid:
                            moves.append(((r, c), (er, ec)))
    return moves

# AI: make a random move
def ai_random_move():
    global turn
    moves = get_all_possible_moves("b")
    if moves:
        start, end = random.choice(moves)
        move_piece(start, end)
        check_game_state()
        turn = "w"

# Main loop
# Main loop
def main():
    global selected_square, turn, error_message
    clock = pygame.time.Clock()
    running = True

    while running:
        clock.tick(60)
        draw_board()
        pygame.display.update()

        if turn == "b":
            pygame.time.delay(500)
            ai_random_move()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and turn == "w":
                pos = pygame.mouse.get_pos()
                row, col = get_square(pos)

                # Deselect the piece if the player clicks on the already selected square
                if selected_square == (row, col):
                    selected_square = None
                    error_message = ""

                # If a new piece is selected, handle move logic
                elif selected_square:
                    valid, message = is_valid_move(selected_square, (row, col))
                    if valid:
                        move_piece(selected_square, (row, col))
                        check_game_state()
                        turn = "b"
                        selected_square = None
                        error_message = ""
                    else:
                        error_message = message
                else:
                    if board[row][col] != "" and board[row][col][0] == turn:
                        selected_square = (row, col)
                        error_message = ""

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
